
package ClassesUsed;

public class FactoryManager extends User {
    public void signUpNewUsers()
    {
        
    }
    public void removeUser()
    {
        
    }
    public void addNewProject()
    {
        
    }
    public void hireFire()
    {
        
    }
    public void orderRawMaterials()
    {
        
    }
}
