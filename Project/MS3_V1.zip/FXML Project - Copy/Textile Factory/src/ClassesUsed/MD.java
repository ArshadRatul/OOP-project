
package ClassesUsed;


public class MD extends User{
    public void CheckCompanyProgressReport()
    {
        
    }
    public void CheckAppointment()
    {
        
    }
    public void CheckEmployeeAttendance()
    {
        
    }
    public void CheckReminders()
    {
        
    }
    public void CheckPayments()
    {
        
    }
    public void CheckFeedback()
    {
        
    }
}
