
package ClassesUsed;

public class FactoryManager extends User {

    public FactoryManager(String Name, String Username, String Password, String Email, String Category, int Mobile) {
        super(Name, Username, Password, Email, Category, Mobile);
    }
    
    public void signUpNewUsers()
    {
        
    }
    public void removeUser()
    {
        
    }
    public void addNewProject()
    {
        
    }
    public void hireFire()
    {
        
    }
    public void orderRawMaterials()
    {
        
    }
}
