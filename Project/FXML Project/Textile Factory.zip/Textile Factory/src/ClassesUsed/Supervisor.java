
package ClassesUsed;


public class Supervisor extends User{

    public Supervisor(String Name, String Username, String Password, String Email, String Category, int Mobile) {
        super(Name, Username, Password, Email, Category, Mobile);
    }

    void setDailyInput()
    {
        
    }
    void viewRemarks()
    {
        
    }
    void checkTarget()
    {
        
    }
    void scheduleForWorkers()
    {
        
    }
    void giveReviewOfRawMaterials()
    {
        
    }
}
