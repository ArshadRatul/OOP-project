
package ClassesUsed;

public class FactoryManager extends User {

    public FactoryManager(String Name, String Username, String Password, String Email, String Category, int Mobile, date DOB) {
        super(Name, Username, Password, Email, Category, Mobile, DOB);
    }

    public void signUpNewUsers()
    {
        
    }
    public void removeUser()
    {
        
    }
    public void addNewProject()
    {
        
    }
    public void hireFire()
    {
        
    }
    public void orderRawMaterials()
    {
        
    }
}
