
package ClassesUsed;

import java.util.ArrayList;


public class Client extends User{


    ArrayList<CheckAppointment> list=new ArrayList();

    public Client(String Name, String Username, String Password, String Email, String Category, int Mobile, date DOB) {
        super(Name, Username, Password, Email, Category, Mobile, DOB);
    }
    
    public void CheckAppointment()
    {
        
    }
    void orderProducts()
    {
        
    }
    void seeOtherClients()
    {
        
    }
    void checkCart()
    {
        
    }
    void seeLiveWorkProgress()
    {
        
    }
    void giveFeedback()
    {
        
    }
    void paymentInformation()
    {
        
    }
            
}
