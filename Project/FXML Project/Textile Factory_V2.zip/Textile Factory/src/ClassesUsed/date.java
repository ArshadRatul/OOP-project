
package ClassesUsed;

public class date {
    int day,month,year;
}
