
package model;


public class Hospital extends User 
{
    public String name;
    public String location;
    
    public void saveAnotherHospitalBMAList()
    {
    
    }
    
    public void saveMemberInfo()
    {
        
    }
    public void seeCommiteeWork()
    {
        
    }
    
    public void complain()
    {
        
    }
    
    
}
