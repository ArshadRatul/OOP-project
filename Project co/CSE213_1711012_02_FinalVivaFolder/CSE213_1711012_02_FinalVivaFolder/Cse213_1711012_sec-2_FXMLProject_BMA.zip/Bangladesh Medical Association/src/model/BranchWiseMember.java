
package model;


public class BranchWiseMember extends User
{
    public void selectBranch()
    {
        
    }
    public void selectBranchDivision()
    {
        
    }
    
    public void inputMemberType()
    {
        
    }
    
    public void viewAndPrintMemberDetails()
    {
        
    }
    
}
