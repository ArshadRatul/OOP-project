
package model;

public abstract class User 
{
    protected String id, password;
    
    public  void verifyLogin(String id, String password)
    {
        
    }
    
    public void canSignUp() //user registration
    {
        
    }
    
}
