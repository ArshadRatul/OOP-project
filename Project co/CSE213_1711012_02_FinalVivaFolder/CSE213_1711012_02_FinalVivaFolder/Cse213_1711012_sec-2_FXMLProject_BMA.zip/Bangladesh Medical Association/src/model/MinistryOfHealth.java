
package model;


public class MinistryOfHealth extends User 
{
    public void approveCommiteeList()
    {
        
    }
    
    public void seeMemberInfo()
    {
        
    }   
    
    public void feedBack()
    {
        
    }
            
    public void solutionProblem()
    {
        
    }
    
    
    
    
    
    
}
