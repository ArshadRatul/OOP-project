
package model;


public class Doctor  extends User
{
    String qualification;
    int noOfHour;
    
    public void createOnlineMemberShip()
    {
        
    }
    
    public void checkBMAHistory()
    {
        
    }
    
    public void checBMAConstitution()
    {
        
    }
    
    
    public void sendMessage()
    {
        
    }
            
    
    
    
    
    
}
