
package model;


public class Admin  extends User
{
    public void addUser()
    {
        
    }
    
    public void removeUser()
    {
        
    }
    public void newClient(String clientId)
    {
        
    }
    
    public void manageUserProfile()
    {
        
    }
    
    
}
