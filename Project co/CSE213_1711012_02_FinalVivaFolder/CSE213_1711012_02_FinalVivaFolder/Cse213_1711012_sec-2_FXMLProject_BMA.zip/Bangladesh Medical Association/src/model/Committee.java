
package model;


public class Committee extends User 
{
    
    public void makeCommiteeList()
    {
        
    }
    
    public void sendCommiteeList()
    {
        
    }
    public void makeAppointment()
    {
        
    }
    public void votingDate()
    {
        
    }
    
    
}
