/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextArea;

/**
 * FXML Controller class
 *
 * @author Abhi
 */
public class ApprovetheCommitteelist2ndSceneController implements Initializable {

    @FXML
    private TextArea seeTheMemberListTextArea;
    @FXML
    private TextArea seeTheMemberCommiteeArea;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void approveBtnOnClick(ActionEvent event) {
    }
    
}
