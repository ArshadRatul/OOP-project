package users;

import mainpkg.*;
import java.util.Scanner;

public class Student extends Person{
    private int id;
    private float cgpa;
    //total 5 fields

    public Student() {
    }
    /*
    public Student(int id, float cgpa, String name, String dob, String gender) {
 	//Person(name, dob, gender);
        super(name, dob, gender);
        this.id = id;
	this.cgpa = cgpa;
	//this.name = name;
        //this.dob = dob;
	//this.gender = gender;
    }
    */

    public Student(int id, float cgpa, String name, String dob, String gender) {
        super(name, dob, gender);
        this.id = id;
        this.cgpa = cgpa;
    }
    

    

    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public float getCgpa() {
        return cgpa;
    }

    public void setCgpa(float cgpa) {
        this.cgpa = cgpa;
    }
    /*
    //Will work for inherited protected fields
    public void setStudInfo(){
        Scanner s = new Scanner(System.in);
        System.out.print("Enter id: ");
        id = s.nextInt();
        s.nextLine();
        System.out.print("Enter name: ");
        name = s.nextLine();
        System.out.print("Enter date of birth: ");
        dob = s.nextLine();
        System.out.print("Enter gender: ");
        gender = s.nextLine();       
        System.out.print("Enter cgpa: ");
        cgpa = s.nextFloat();
    }
    */
    public void setStudInfo(){
        Scanner s = new Scanner(System.in);
        System.out.print("Enter id: ");
        id = s.nextInt();
        s.nextLine();
        System.out.print("Enter name: ");
        setName( s.nextLine() );
        System.out.print("Enter date of birth: ");
        setDob( s.nextLine() );
        System.out.print("Enter gender: ");
        setGender( s.nextLine() );       
        System.out.print("Enter cgpa: ");
        cgpa = s.nextFloat();
    }

    /*
    //Will work for inherited protected fields
    public void showStudInfo(){
        //System.out.println("Showing student info...");
        System.out.println("id="+id+", Name="+name+
                ", DateOfBirth="+dob+", Gender="+gender+", Cgpa="+cgpa);
    }
    */
    //Need to use setter of superclass to set inherited private fields
    public void showStudInfo(){
        //System.out.println("Showing student info...");
        System.out.println("id="+id+", Name="+getName()+
                ", DateOfBirth="+getDob()+", Gender="+getGender()+", Cgpa="+cgpa);
    }

    @Override
    public String toString() {
        return "Student{" + "id="+id+", Name="+name+
                ", DateOfBirth="+dob+", Gender="+gender+", Cgpa="+cgpa+ '}';
    }


    
}
