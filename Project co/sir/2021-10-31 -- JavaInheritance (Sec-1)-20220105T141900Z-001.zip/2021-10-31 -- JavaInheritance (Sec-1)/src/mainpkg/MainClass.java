package mainpkg;

import java.util.Random;
import java.util.Scanner;
import users.Person;
import users.Student;


public class MainClass {
    /*
    public static void main(String[] args) {
        Random r = new Random();
        Scanner s = new Scanner(System.in);
        Student asif;
        asif = new Student();
        asif.setStudInfo();
        System.out.println("Student detail: ");
        asif.showStudInfo();
    }
    */
    
    public static void main(String[] args) {
        Random r = new Random();
        Scanner s = new Scanner(System.in);
        Student asif;
        asif = new Student(111,3.56f,"Asif","12/10/20","Male");
        //asif.setStudInfo();
        System.out.println("Student detail: ");
        //asif.showStudInfo();
        System.out.println(asif);
    }
    
    /*
    public static void main(String[] args) {
        Person p = new Person();
        
        
        Scanner s = new Scanner(System.in);
        Student asif;
        asif = new Student(111,3.56f,"Asif","12/10/20","Male");
        //asif.setStudInfo();
        System.out.println("Student detail: ");
        asif.showStudInfo();
    }
    */

}

