/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpkg;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author Subrata Kumar Dey
 */
public class ArithmeticOperationDemoSceneController implements Initializable {

    @FXML    private Label resultLabel;
    @FXML    private TextField textFieldX;
    @FXML    private TextField textFieldY;
    
    //private String str;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void addButtonOnClick(ActionEvent event) {
        //ArrayList<int> intList = new ArrayList<int>();
        ArrayList<Integer> intList = new ArrayList<Integer>();
        intList.add(12); int x=20; intList.add(x);
        System.out.println((float)x);
        
        /*
        String xStr, yStr, resultStr;
        xStr = textFieldX.getText();
        yStr = textFieldY.getText();
        int xVal, yVal, resultVal;
        xVal = Integer.parseInt(xStr);
        yVal = Integer.parseInt(yStr);
        resultVal = xVal+yVal;
        resultStr = Integer.toString(resultVal);
        resultLabel.setText(resultStr);
        */
        
        resultLabel.setText(
            Integer.toString(
                    Integer.parseInt(textFieldX.getText())                   
                    +
                    Integer.parseInt(textFieldY.getText())
            )
        );
    }

    @FXML
    private void subtractButtonOnClick(ActionEvent event) {
        resultLabel.setText(
            "X-Y = " + 
            (
                Integer.parseInt(textFieldX.getText())
                -
                Integer.parseInt(textFieldY.getText())
            )
        );        
    }

    @FXML
    private void multiplyButtonOnClick(ActionEvent event) {
    }
    
}
