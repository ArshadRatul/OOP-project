package mainpkg;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import modelclasses.Student;

public class FileHandlingDemoSceneController implements Initializable {

    @FXML    private TextField idTextField;
    @FXML    private TextField nameTextField;
    @FXML    private TextField cgpaTextField;
    @FXML    private TextField fileNameTextField;
    @FXML    private Label fileContentLabel;

    private ArrayList<Student> studList;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        studList = new ArrayList<Student>();
        // TODO
    }    

    @FXML
    private void writeToFileButtonOnClick(ActionEvent event) {
        File f; FileWriter fw=null;
        try {
            //Character Stream
            
            //Option-1:
            //FileWriter fw = new FileWriter("test.txt");
            //-------------------------------------------
            //Option-2:
            //File f = new File("test.txt");
            //FileWriter fw = new FileWriter(f);
            //--------------------------------
            //Option-3: Using FileChooser
            //-----------------------------
            
            //Write mode:
            //FileWriter fw = new FileWriter(fileNameTextField.getText());

            //Append mode:
            //FileWriter fw = new FileWriter(fileNameTextField.getText(), true);

            f = new File("dummy2.txt");
            if(f.exists()) fw = new FileWriter(f,true);
            else fw = new FileWriter(f);
            /*
            String content = idTextField.getText()+","+
                                nameTextField.getText()+","+
                                cgpaTextField.getText()+"\n";
            fw.write(content);
            */
            
            //for(Student s: studList) fw.write(s.toString());
            for(Student s: studList) 
                fw.write(s.getId()+","+s.getName()+","+s.getCgpa()+"\n");
            //other statements, and exception occurs here
            //fw.close();
        } 
        catch (IOException ex) {
            //fw.close();
        }
        catch (NullPointerException e) {
            //fw.close();
        }
        catch (ArrayIndexOutOfBoundsException e) {
            //fw.close();
        }
        catch (Exception e) {
            //fw.close();
        }


        finally{
            try {
                fw.close();
                //write your custom handling code
                //Logger.getLogger(FileHandlingDemoSceneController.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex1) {
                Logger.getLogger(FileHandlingDemoSceneController.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }
    }

    @FXML
    private void idTextFieldOnClick(MouseEvent event) {
        idTextField.setText("");
    }

    @FXML
    private void cgpaTextFieldOnClick(MouseEvent event) {
        cgpaTextField.clear();
    }

    @FXML
    private void nameTextFieldOnClick(MouseEvent event) {
        nameTextField.clear();
    }

    @FXML
    private void readFromFileButtonOnClick(ActionEvent event) {
        try {
            File f = new File(fileNameTextField.getText());
            Scanner s = new Scanner(f);
            //fileContentLabel.setText(  s.nextLine() );
                        
            /*
            String line = s.nextLine();
            String[] tokens = line.split(",");
            fileContentLabel.setText(  
                "Id="+tokens[0]+
                ", Name="+tokens[1]+
                ", Cgpa="+tokens[2]            
            );
            */
            
            String line, content=""; String[] tokens;
            while(s.hasNextLine()){
                line = s.nextLine();
                tokens = line.split(",");
                content += "Id="+tokens[0]+", Name="+tokens[1]+", Cgpa="+tokens[2]+"\n"; 
            }
            fileContentLabel.setText(content);               
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FileHandlingDemoSceneController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void addToArrayListButtonOnClick(ActionEvent event) {
        studList.add(
            new Student(
                Integer.parseInt(idTextField.getText()),
                nameTextField.getText(),
                Float.parseFloat(cgpaTextField.getText())
            )
        );
    }
    
}
