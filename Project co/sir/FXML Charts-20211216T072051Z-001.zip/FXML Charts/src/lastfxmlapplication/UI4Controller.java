package lastfxmlapplication;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;

public class UI4Controller implements Initializable {

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
