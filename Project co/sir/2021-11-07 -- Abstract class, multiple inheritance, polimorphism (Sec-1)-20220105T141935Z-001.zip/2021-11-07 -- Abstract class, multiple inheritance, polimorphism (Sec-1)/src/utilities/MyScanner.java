package utilities;

import java.util.Scanner;

//public class MyScanner extends Scanner{}
