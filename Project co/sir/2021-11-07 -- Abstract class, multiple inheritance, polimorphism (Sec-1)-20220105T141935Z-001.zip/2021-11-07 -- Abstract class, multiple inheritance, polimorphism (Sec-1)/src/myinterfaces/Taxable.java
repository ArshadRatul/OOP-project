package myinterfaces;

public interface Taxable {
    public float calcTaxAmount();
    
    
}
